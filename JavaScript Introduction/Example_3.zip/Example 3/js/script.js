function addSomeText() {
  document.body.innerHTML += "<p>Function executed!</p>";
}